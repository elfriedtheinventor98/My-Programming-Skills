﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Surface_POO
{
    public partial class Carré: Figure
    {
        private double Côté;

        public Carré(double c,string unité):base( unité
            )
        {
            this.Côté = c;

        }
        public override double Surface()
        {
           

           return Côté * Côté;
        }
        public override void Decrire()
        {
            Console.WriteLine("La surface du carré est de " + Surface() + " " + unité + " carré(s).");
        }

    }
}
