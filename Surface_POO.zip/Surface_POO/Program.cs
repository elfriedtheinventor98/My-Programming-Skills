﻿

namespace Surface_POO
{

    internal class Program

    {
        static void Main(string[] args)
        {
            Figure f1 = new Rectangle(5, 10, "cm");
            f1.Decrire();

            Figure f2 = new Carré(7, "m");
            f2.Decrire();


        }


    }
}
  