﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Surface_POO
{
     public partial class Rectangle : Figure
    {
        private double Longueur;
        private double Largeur;

        public Rectangle(double longueur, double largeur, string unite) : base(unite)
        {
            this.Longueur = longueur;
            this.Largeur = largeur;
        }

        public override double Surface()
        {
            return Longueur * Largeur;
        }

        public override void Decrire()
        {
            Console.WriteLine("La surface du rectangle est de " + Surface() + " " + unité + " carré(s).");
        }

    }
}
