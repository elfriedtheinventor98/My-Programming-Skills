﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Surface_POO
{
    public abstract class Figure
    {
        protected string unité;

        
        private string Unité
        {


            get { return Unité; }
            set { Unité = value; }

        }
        public Figure( string u) 
        
        {
            this.unité = u;
        
        }
        public abstract double Surface();

        public abstract void Decrire();
        
    }
}
